<!DOCTYPE html>
<html lan="en">
<body>

 
<?php include('header.php'); ?>
<?php if (isset($_SESSION['login_user'])){
	if(!selectRight('tmlHomePageGreeting',$dbcon)){
		echo("<div>Welcome " . htmlentities($_SESSION['greeting']) . "</div>");
	}else{
		echo("<div id=div></div>");
		?>
		<script> $('#div').html("Welcome <?php echo $_SESSION['greeting']?>"); </script>
		<?php
		}
}
?>

</body>
</html>
