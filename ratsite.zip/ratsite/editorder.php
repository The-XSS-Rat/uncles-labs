<!DOCTYPE html>
<html lang="en">
<?php include('header.php'); ?>
<?php
if(!selectRight('BACOrdersEdit',$dbcon)){
	if (!$userRights['canEditOrders']) {
   	 header("location: login.php");
   	 exit();
	}
}

if (isset($_GET['id'])) {
	$getOrder_query = "SELECT * FROM orders where inv_id=" . $_GET['id'];
	$invresult = mysqli_query($dbcon, $getOrder_query);
	$rowOrder = mysqli_fetch_assoc($invresult);
	if(!$ini['IDOROrdersDetail'] && ($rowOrder['userID'] != $_SESSION['userID'])){
		echo "error, not your item";
		die;
	}

}

if(isset($_POST['ordDES'])){
			$inv_id = mysqli_real_escape_string($dbcon, $_POST['inv_id_sel']);
			$ordQTY = mysqli_real_escape_string($dbcon, $_POST['ordQTY']);
			$ordDES = mysqli_real_escape_string($dbcon, $_POST['ordDES']);
	
			//Check to make sure form is complete when posting:
			if (empty($inv_id)) { array_push($errors, "Invoice ID must be set"); echo "Invoice ID must be set! "; } else { $_SESSION['inv_id']= $inv_id;  }
			if (empty($ordQTY)) { array_push($errors, "Order Quantity must be set"); echo "Order Quantity must be set! "; } else { $_SESSION['ordQTY']= $ordQTY; }
			if (empty($ordDES)) { array_push($errors, "Order Description must be set"); echo "Order Description must be set! "; } else { $_SESSION['ordDES']= $ordDES; }

			if ($errors == 0) {
				$ord_query = "UPDATE orders SET qty=$ordQTY, description='$ordDES' WHERE inv_id=$inv_id";
				echo $ord_query;
				if(!selectRight('CSRFEditOrders',$dbcon)){
					if(isset($_POST['CSRF']) && $_POST['CSRF'] == $_SESSION['token']){
						mysqli_query($dbcon, $ord_query);
					}
				}else{
						mysqli_query($dbcon, $ord_query);				
					}
				echo "<h1>Submitted Successfully!</h1>";
				sleep(3);
				$_SESSION['inv_id']= "";
				$_SESSION['ordQTY']="";
				$_SESSION['ordDES']="";
				header("location:/ratsite/orders.php");
			}
}

?>


<form name="neword" id="neword" method="post"  >


<div>
</div>
<label>Invoice ID:</label>
<input value="<?php echo $rowOrder['inv_id']; ?>" type="number" name="inv_id_sel" id="inv_id_sel" readonly>
<div>
<label>Order Quantity:  </label>
<div>
<div></div>
<input value="<?php echo $rowOrder['qty']; ?>" type="number" name="ordQTY" id="ordQTY">
</div>
</div>
<div>
<label>Order Description:  </label>
<div>
<div></div>
<input value="<?php echo $rowOrder['description']; ?>" type="text"  name="ordDES" id="ordDES">
<input type="text" value="<?php echo $_SESSION['token']?>" name="CSRF"  id="CSRF" hidden>
</div>
</div>
<input type="submit" value="Submit">

</form>








</html>
