<?php include('header.php');


if (isset($_GET['id'])) {
	$invID = mysqli_real_escape_string($dbcon, $_GET['id']);
	if(!selectRight('IDOROrdersDelete',$dbcon)){
		$delQuery = "DELETE FROM orders WHERE userID=" . $_SESSION['userID'] . " AND inv_id=" . $invID;
	}else{
		$delQuery = "DELETE FROM orders WHERE inv_id=" . $invID;
	}
	if($invresults = mysqli_query($dbcon, $delQuery)){
		echo "<script>window.location.href = 'orders.php'; </script>";
	}
}

