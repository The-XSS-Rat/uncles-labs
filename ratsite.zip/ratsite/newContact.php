<!DOCTYPE html>
<html lang="en">
<?php include('header.php'); ?>
<?php

if(!$ini['BACInvoicesDetail']){
    include('security.php');
}

if (isset($_POST['firstname'])) {
	//$invID = mysqli_real_escape_string($dbcon, $_POST['invID']);
	$firstname = mysqli_real_escape_string($dbcon, $_POST['firstname']);
	$lastname = mysqli_real_escape_string($dbcon, $_POST['lastname']);
	if(isset($_POST['public'])){
		$public = 1;
	}else{
		$public = 0;
	}
	$email = mysqli_real_escape_string($dbcon, $_POST['email']);

	$userID = $_SESSION['userID'];
	$inv_query = "INSERT INTO contacts(firstname, lastname, email, public,userID)
		VALUES('$firstname', '$lastname', '$email', $public,'$userID')";
	echo $inv_query;
	mysqli_query($dbcon, $inv_query);
	echo "<h1>Submitted Successfully!</h1>";
	sleep(2);
    echo "<script>window.location.replace('contacts.php') </script>";

}

?>


<form method="post"  >


<div></div>
</div>
</div>
<div>
<label>firstname:  </label>
<div>
<div></div>
<input value="<?php echo $_SESSION['firstname']; ?>" type="text"  name="firstname" id="firstname" required>
</div>
</div>
<div>
<label>lastname:  </label>
<div>
<div></div>
<input value="<?php echo $_SESSION['lastname']; ?>" type="text" name="lastname" id="lastname" required>
</div>
</div>
<div>
<label>email:  </label>
<div>
<div></div>
<input value="<?php echo $_SESSION['email']; ?>" type="text"  name="email" id="email" required>
</div>
</div>
<div>
<label>Public:  </label>
<div>
<div></div>
<input value="<?php echo $_SESSION['public']; ?>" type="checkbox"  name="public" id="public">
</div>
</div>
<input type="submit" value="Submit">

</form>








</html>
