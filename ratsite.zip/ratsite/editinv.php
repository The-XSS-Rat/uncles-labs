<!DOCTYPE html>
<html lang="en">
<?php include('header.php'); ?>
<?php


if(!selectRight('BACInvoicesEdit',$dbcon)){
	if (!$userRights['canEditInvoices']) {
   	 header("location: login.php");
   	 echo "no rights";
   	 exit();
	}
}
if(!selectRight('BACInvoicesDetail',$dbcon)){
    include('security.php');
}

if (isset($_POST['invDATE'])) {
	$invID = mysqli_real_escape_string($dbcon, $_POST['invID']);
	$invDATE = mysqli_real_escape_string($dbcon, $_POST['invDATE']);
	$fromNAME = mysqli_real_escape_string($dbcon, $_POST['fromNAME']);
	$fromST = mysqli_real_escape_string($dbcon, $_POST['fromST']);
	$fromSTATE = mysqli_real_escape_string($dbcon, $_POST['fromSTATE']);
	$total = mysqli_real_escape_string($dbcon, $_POST['total']);


//Check to make sure form is complete when posting:
if (empty($invDATE)) { array_push($errors, "Invoice Date must be set"); echo "Invoice Date must be set! "; die;} else { $_SESSION['invDATE']= $invDATE; }
if (empty($fromNAME)) { array_push($errors, "Invoice Name must be set"); echo "Invoice Name must be set! "; die;} else { $_SESSION['fromNAME']= $fromNAME; }
if (empty($fromST)) { array_push($errors, "Invoice Street must be set"); echo "Invoice Street must be set! "; die;} else {$_SESSION['fromST']= $fromST; }
if (empty($fromSTATE)) { array_push($errors, "Invoice State must be set"); echo "Invoice State must be set! "; die;} else {$_SESSION['fromSTATE']= $fromSTATE; }
if (empty($total)) { array_push($errors, "Invoice Total must be set"); echo "Invoice Total must be set! "; die;} else {$_SESSION['total']= $total; }



if ($errors == 0) {
	$inv_query = "UPDATE invoice set date=\"$invDATE\", from_name=\"$fromNAME\", from_street=\"$fromST\", from_state=\"$fromSTATE\", total=$total
		WHERE inv_id=$invID";
		echo $inv_query;
				if(!selectRight('CSRFEditInv',$dbcon)){
					if(isset($_POST['CSRF']) && $_POST['CSRF'] == $_SESSION['token']){
						mysqli_query($dbcon, $inv_query);
					}
				}else{
						mysqli_query($dbcon, $inv_query);				
				}
				echo "<h1>Submitted Successfully!</h1>";
	sleep(2);
	$_SESSION['invDATE']= "";
	$_SESSION['fromNAME']="";
	$_SESSION['fromST']="";
	$_SESSION['fromSTATE']="";
	$_SESSION['total']="";
	header("location:/ratsite/invoices.php");
	}

}





?>


<form name="editinv" action="/ratsite/editinv.php" method="post"  >
<?php

if (isset($_GET['id'])) {
	$invID = mysqli_real_escape_string($dbcon, $_GET['id']);
	$invlist_query = "SELECT * FROM invoice WHERE inv_id=" . $invID;
	$invresults = mysqli_query($dbcon, $invlist_query);
	while ($row = mysqli_fetch_assoc($invresults)){
		if(!$ini['IDORInvoicesDetail'] && ($row['userID'] != $_SESSION['userID'])){
			echo "error, not your item";
			die;
		}
		?>
		ID: <input type='text'  name='invID' id='invID' value='<?php echo $invID;?>' readonly>
		<br>
		Date: <input type='date'  name='invDATE' id='invDATE' placeholder='Date' value='<?php echo $row['date']; ?>'>
		<br>
		Name: <input value="<?php echo $row['from_name']; ?>" type="text" name="fromNAME" id="fromNAME" placeholder="Name">
		<br>
		Street: <input value="<?php echo $row['from_street']; ?>" type="text"  name="fromST" id="fromST" placeholder="Street">
		<br>
		State: <input value="<?php echo $row['from_state']; ?>" type="text"  name="fromSTATE" id="fromSTATE" placeholder="State">
		<br>
		Invoice total: <input value="<?php echo $row['total']; ?>" type="number" name="total" id="total" placeholder="Total Amount">
		<input type="text" value="<?php echo $_SESSION['token']?>" name="CSRF"  id="CSRF" hidden>

		<br>		
		<?php
	}
}
?>
<input type="submit" value="Submit">

</form>








</html>
