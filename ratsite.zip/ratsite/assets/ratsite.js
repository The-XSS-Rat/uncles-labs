// These are experimental parameters, remove them before going into PRD
// invoices.php?display=test 
// processCheese.php?display=test	

const jwt = require("jsonwebtoken");

describe('angularjs homepage todo list', function() {

	const domain = "dev.terra.vlaanderen.be";

    // Create token
    const token = jwt.sign(
      {
"urn:be:vlaanderen:terra:acmid": "451a09f1-ba10-4a6d-8a14-4841e7c974db",
  "name": "m?????",
  "given_name": "m?????",
  "urn:be:vlaanderen:terra:organisation": "m?????",
  "role": "m?????",
  "nbf": 1646230390,
  "exp": 1649232055,
  "iat": 1646230390,
  "iss": "m?????",
  "aud": "hm?????" },
      "m?????",
      {
        
      }
    );
  console.log(token);



  it('should add a todo', function() {
  
    browser.get('');
    browser.get('');

	browser.manage().getCookies().then(function(cookies) {
    	console.dir(cookies);
	});
	

	var OrgLink = element(by.xpath('//div[4]/app/header/div/div[4]/ul/li[2]/a'));
	OrgLink.click();
	
	var orgDetail = element(by.xpath('/html/body/div[4]/app/div[3]/div[2]/ng-component/div/div/div/div/table/tbody/tr[1]/td[2]/a'));
	orgDetail.click();
	
	var homeLink = element(by.xpath('/html/body/div[4]/app/header/div/div[4]/ul/li[1]/a'));
	homeLink.click();
	
	var patLink = element(by.xpath('/html/body/div[4]/app/header/div/div[4]/ul/li[3]/a'));
	patLink.click();
	
	var patDetail = element(by.xpath('//*[@id="main"]/div[2]/ng-component/div/div/div/div/table/tbody/tr[1]/td[1]/a'));
	patDetail.click();
	
	homeLink.click();
	
	var sitesLink = element(by.xpath('/html/body/div[4]/app/header/div/div[4]/ul/li[4]/a'));
	sitesLink.click();
	
	var sitesDetail = element(by.xpath('/html/body/div[4]/app/div[3]/div[2]/ng-component/div/div/div/div/table/tbody/tr[2]/td[1]/a'));
	sitesDetail.click();
	homeLink.click();
	
	var valLink = element(by.xpath('/html/body/div[4]/app/header/div/div[4]/ul/li[5]/a'));
	valLink.click();
	
	var valDetail = element(by.xpath('/html/body/div[4]/app/div[3]/div[2]/ng-component/div/div/div/div[2]/table/tbody/tr[1]/td[1]/a'));
	valDetail.click();
	homeLink.click();
	
	var energieDragersLink = element(by.xpath('/html/body/div[4]/app/header/div/div[4]/ul/li[6]/a'));
	energieDragersLink.click();
	
	var energieDragerDetail =  element(by.xpath('/html/body/div[4]/app/div[3]/div[2]/ng-component/div/div/div/div/table/tbody/tr[1]/td[1]/a'));
	energieDragerDetail.click();
	homeLink.click();
	
	var AanvragenLink = element(by.xpath('/html/body/div[4]/app/header/div/div[4]/ul/li[7]/a'));
	AanvragenLink.click();	
	
	var AanvragenDetail = element(by.xpath('/html/body/div[4]/app/div[3]/div[2]/ng-component/div/div/div/div/table/tbody/tr[1]/td[1]/a'));
	AanvragenDetail.click();
	homeLink.click();
	
	var MaatregelenLink = element(by.xpath('/html/body/div[4]/app/header/div/div[4]/ul/li[8]/a'));
	MaatregelenLink.click();
	
	var maatRegelDetail = element(by.xpath('/html/body/div[4]/app/div[3]/div[2]/ng-component/div[2]/div/div/div/table/tbody/tr[1]/td[1]/a'));
	maatRegelDetail.click();
	homeLink.click();
	
	var OpdrachtenLink = element(by.xpath('/html/body/div[4]/app/header/div/div[4]/ul/li[9]/a'));
	OpdrachtenLink.click();	
	
	var opdrachtenDetail = element(by.xpath('/html/body/div[4]/app/div[3]/div[2]/ng-component/ng-component/div[2]/div/div/div/table/tbody/tr[1]/td[1]/a'));
	opdrachtenDetail.click();
	homeLink.click();
	
	var SubsLink = element(by.xpath('/html/body/div[4]/app/header/div/div[4]/ul/li[10]/a'));
	SubsLink.click();		
	homeLink.click();
	
	var KlimaatPlLink = element(by.xpath('/html/body/div[4]/app/header/div/div[4]/ul/li[11]/a'));
	KlimaatPlLink.click();	
		
	browser.sleep(1000);
  });
});
