<!DOCTYPE html>
<html lang="en">
<?php include('header.php'); ?>
<?php
if(!selectRight('BACOrdersCreate',$dbcon)){
	if (!isset($userRights['canCreateOrders'])) {
   	 header("location: login.php");
   	 exit();
	}
}


if(!selectRight('BACOrdersCreate',$dbcon) || !selectRight('IDOROrdersDetail',$dbcon)){
    include('security.php');
}

if (isset($_POST['ordQTY'])) {
	$ordQTY = mysqli_real_escape_string($dbcon, $_POST['ordQTY']);
	$ordDES = mysqli_real_escape_string($dbcon, $_POST['ordDES']);


//Check to make sure form is complete when posting:
if (empty($ordQTY)) { array_push($errors, "Order Quantity must be set"); echo "Order Quantity must be set! "; } else { $_SESSION['ordQTY']= $ordQTY; }
if (empty($ordDES)) { array_push($errors, "Order Description must be set"); echo "Order Description must be set! "; } else { $_SESSION['ordDES']= $ordDES; }



if ($errors == 0) {
	$userID = $_SESSION['userID'];

	$ord_query = "INSERT INTO orders(inv_id, qty, description, userID)
		VALUES(null, '$ordQTY', '$ordDES','$userID')";
	mysqli_query($dbcon, $ord_query);
	echo "<h1>Submitted Successfully!</h1>";
	sleep(3);
	$_SESSION['inv_id']= "";
	$_SESSION['ordQTY']="";
	$_SESSION['ordDES']="";
	header("location:/ratsite/orders.php");
	}

}

?>


<form name="neword" id="neword" action="neworder.php" method="post"  >
<div>
<label>Order Quantity:  </label>
<div>
<div></div>
<input value="<?php echo $_SESSION['ordQTY']; ?>" type="number" name="ordQTY" id="ordQTY" required>
</div>
</div>
<div>
<label>Order Description:  </label>
<div>
<div></div>
<input value="<?php echo $_SESSION['ordDES']; ?>" type="text"  name="ordDES" id="ordDES" required>
</div>
</div>
<input type="submit" value="Submit">

</form>








</html>
