<?php
include('header.php');
function checkJWT($jwt){
	$body = json_decode(getBody($jwt));
	if($body->isAdmin=="True"){
		echo "Good job!! The flag is flag{1_L0v#3_Ch33s3!}";
	}else{
		echo "You can not read the flag";
	}
}

if(selectRight('JWTLeakSecret',$dbcon)){

	echo "<!--Codename: secret 
	This is so you won't forget the JWT again charlie, please stop messing up! -->";
}
?>

<form>
  <label for="JWT">Your JWT:</label><br>
  <input type="text" id="JWT" name="JWT"><br>
  <input type="submit"> 
</form>

<?php

if(isset($_GET['JWT'])){
	echo checkJWT($_GET['JWT']);
}