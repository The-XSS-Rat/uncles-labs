<!DOCTYPE html>
<html lang="en">
<body>
<div class="center">
<?php include('header.php');

if(!selectRight('BACInvoicesOverview',$dbcon)){
    include('security.php');
     if (!$userRights['canSeeInvoices']) {
    	header("location: login.php");
    	exit();
	}
}
?>

<form>
Search on the senders' name:
<input name="searchTerm">
<input type="submit">
</form>


<br>

<?php
$userID = $_SESSION['userID'];

if(isset($_GET['searchTerm'])){
	$searchterm = $_GET['searchTerm'];
	if(!selectRight('tmlEntDisabledInvoicesSearch',$dbcon)){
		echo "Searching for " . htmlentities($searchterm);
	}else{
		echo "Searching for " . $searchterm;
	}
	$sql = "SELECT * FROM invoice where from_name='" . $searchterm . "'";
}else{
	if(isset($_GET['pageNum'])){
		$lowerLim = $_GET['pageNum']*5;
	}else{
		$lowerLim = 0;
	}
	
	$sql = "SELECT * FROM invoice WHERE userID = $userID LIMIT $lowerLim,5";
	
}
$result = mysqli_query($dbcon, $sql); 
echo "<br>";
echo "<table border='1'  style='table-layout: fixed;width:100%'>";
echo "<tr>";
echo "<td><h5>Invoice date</h5></td>";
echo "<td><h5>From name</h5></td>";
echo "<td><h5>From street</h5></td>";
echo "<td><h5>From state</h5></td>";
echo "<td><h5>Amount</h5></td>";
echo "<td><h5>Edit</h5></td>";
echo "<td><h5>Delete</h5></td>";
echo "</tr>";

while ($row = mysqli_fetch_assoc($result)){
    echo "<tr>";
    echo "<td>" . $row['date'] . "</td>";
    echo "<td>" . $row['from_name'] . "</td>";
    echo "<td>" . $row['from_street'] . "</td>";
    echo "<td>" . $row['from_state'] . "</td>";
    echo "<td>" . $row['total'] . "</td>";
    	
	if($userRights['canEditInvoices']){
			echo "<td>" . "<a href=https://hackxpert.com/ratsite/editinv.php?id=" . $row['inv_id'] . ">Edit
			item</a></td>";
	}
	if($userRights['canDeleteInvoices']){
		echo "<td>" . "<a href=https://hackxpert.com/ratsite/delInvoice.php?id=" . $row['inv_id'] . ">Delete item</a></td>"; }
    }
    echo "</tr>";



echo "</table>";

?>

</div>
<div class="center" >

Go to page: <br>
<?php

	$sql = "SELECT * FROM invoice WHERE userID = $userID";
	if ($result=mysqli_query($dbcon,$sql)) {
	    $rowcount=mysqli_num_rows($result);
	    for($x=0;$x<=$rowcount/5;$x+=1){
	    	$pageNum = $x + 1;
	    	echo "<a href=invoices.php?pageNum=$x>" . $pageNum . "</a> | ";
	    }
	}
	if($userRights['canCreateInvoices']){
        echo '<a href="newinv.php">Create New Invoice</a> |';
    }
?>




</div>


</body>



</html>
