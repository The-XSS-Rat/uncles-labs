<!DOCTYPE html>
<html lang="en"> 

<?php
include('header.php');
if (isset($_POST['username'])) {

	$username = mysqli_real_escape_string($dbcon, $_POST['username']);
	$first_name = mysqli_real_escape_string($dbcon, $_POST['first_name']);
	$last_name = mysqli_real_escape_string($dbcon, $_POST['last_name']);

  $password_1 = mysqli_real_escape_string($dbcon, $_POST['pwd']);
  $password_2 = mysqli_real_escape_string($dbcon, $_POST['rpwd']);
  		

  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($username)) { array_push($errors, "Username is required"); }
  if (empty($first_name)) { array_push($errors, "First Name is required"); }
  if (empty($last_name)) { array_push($errors, "Last Name is required"); }

  if (empty($password_1)) { array_push($errors, "Password is required"); }
  if ($password_1 != $password_2) {
	array_push($errors, "The two passwords do not match");
  }
  // first check the database to make sure
  // a user does not already exist with the same username and/or email
  $user_check_query = "SELECT * FROM User WHERE username='$username'  LIMIT 1";
  $result = mysqli_query($dbcon, $user_check_query);
  $userex = mysqli_fetch_assoc($result);
  if ($userex) { // if user exists
    if ($userex['username'] === $username) {
      array_push($errors, "Username already exists");
      echo $errors;
	  die("username already exists");
    }
    
  }
  // Finally, register user if there are no errors in the form
  if (count($errors) == 0) {
  	$password = $password_1; //encrypt the password before saving in the database
  	$query = "INSERT INTO User (username, pass,first_name,last_name)
  			  VALUES ('$username','$password','$first_name','$last_name')";
  	mysqli_query($dbcon, $query);
  	$_SESSION['username'] = $username;
  	
  	$user_id_query = "SELECT id FROM User WHERE username='$username' LIMIT 1";
	$result = mysqli_query($dbcon, $user_id_query);
	$user = mysqli_fetch_assoc($result);
	$userID = $user['id'];
	
	try{
		$query = "insert into userRights values (null,0,0,0,0,0,0,0,$userID,0,0)";
		mysqli_query($dbcon, $query);
  		header('location: index.php');
	} catch (Exception $e) {
    	echo 'Caught exception: ',  $e->getMessage(), "\n";
	}
	}
}
?>




<body>

<div class="center">
 <style>

        .center {
        margin: auto;
        width: 60%;
        padding: 10px;
        text-align: center;
       }

</style>

<form method="post">
	<label for="username">Username:</label><br>
	<input type="text" id="username" name="username"><br>
	<label for="first_name">First Name:</label><br>
	<input type="text" id="first_name" name="first_name"><br>
	<label for="last_name">Last Name:</label><br>
	<input type="text" id="last_name" name="last_name"><br>
	<label for="pwd">Password:</label><br>
	<input type="password" id="pwd" name="pwd"><br>
	<label for="repeat">Repeat Password:</label><br>
	<input type="password" id="rpwd" name="rpwd"><br>
	<input type="submit" value="Submit">

</form>
</div>

</body>
 </html>
