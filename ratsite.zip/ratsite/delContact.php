<?php include('header.php');


if (isset($_GET['id'])) {
	$contactID = mysqli_real_escape_string($dbcon, $_GET['id']);
	if(!selectRight('IDORDeleteContacts',$dbcon)){
		$delQuery = "DELETE FROM contacts WHERE userID=" . $_SESSION['userID'] . " AND id=" . $contactID;
	}else{
		$delQuery = "DELETE FROM contacts WHERE id=" . $contactID;
	}
	if($invresults = mysqli_query($dbcon, $delQuery)){
		echo "<script>window.location.href = 'contacts.php'; </script>";
	}
}

