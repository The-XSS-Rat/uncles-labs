<?php
include("header.php");
include("connect.php");

if(!selectRight('BACUsersOverview',$dbcon)){
    include('security.php');
     if (!$userRights['isAdmin']) {
    	header("location: login.php");
    	exit();
	}
}

// Change a user
if(isset($_POST['rightName'])){
	$boolVal = 0;
	$right = $_POST['rightName'];
	if(isset($_POST['yesno'])){
		$boolVal = 1;
	}

	$userID = mysqli_real_escape_string($dbcon,$_POST['userID']);
	switch ($right) {
    	case "canSeeOrders":
    		$sql = "UPDATE userRights SET canSeeOrders=$boolVal WHERE userID =". $userID;
    		$result = mysqli_query($dbcon, $sql);
    		break;

    	case "canEditOrders":
    		$sql = "UPDATE userRights SET canEditOrders=$boolVal WHERE userID =". $userID;
    		$result = mysqli_query($dbcon, $sql);
    		break;
    		
		case "canDeleteOrders":
    		$sql = "UPDATE userRights SET canDeleteOrders=$boolVal WHERE userID =". $userID;
    		$result = mysqli_query($dbcon, $sql);
    		break;
    		
    	case "canCreateOrders":
    		$sql = "UPDATE userRights SET canCreateOrders=$boolVal WHERE userID =". $userID;
    		$result = mysqli_query($dbcon, $sql);
    		break;
    		
    	case "canSeeInvoices":
    		$sql = "UPDATE userRights SET canSeeInvoices=$boolVal WHERE userID =". $userID;
    		$result = mysqli_query($dbcon, $sql);
    		break;
    		
    	case "canCreateInvoices":
    		$sql = "UPDATE userRights SET canCreateInvoices=$boolVal WHERE userID =". $userID;
    		$result = mysqli_query($dbcon, $sql);
    		break;
    		
    	case "canDeleteInvoices":
    		$sql = "UPDATE userRights SET canDeleteInvoices=$boolVal WHERE userID =". $userID;
    		$result = mysqli_query($dbcon, $sql);
    		break;
    		
    	case "canEditOrders":
    		$sql = "UPDATE userRights SET canEditOrders=$boolVal WHERE userID =". $userID;
    		$result = mysqli_query($dbcon, $sql);
    		break;
    		
    	case "canEditInvoices":
    		$sql = "UPDATE userRights SET canEditInvoices=$boolVal WHERE userID =". $userID;
    		$result = mysqli_query($dbcon, $sql);
    		break;
    		
    	case "isAdmin":
    		$sql = "UPDATE userRights SET isAdmin=$boolVal WHERE userID =". $userID;
    		$result = mysqli_query($dbcon, $sql);
    		break;
    }
}


?>
<br>
<table class="center" border='1'  style='table-layout: fixed;width:90%'>
<tr>
<td>userID</td>
<td>canSeeOrders:</td>
<td>canDeleteOrders:</td>
<td>canCreateOrders:</td>
<td>canDeleteInvoices:</td>
<td>canSeeInvoices:</td>
<td>canCreateInvoices:</td>
<td>canEditInvoices:</td>
<td>canEditOrders:</td>
<td>isAdmin:</td>
</tr>
</table>
<?php
// Display users
	if(isset($_GET['pageNum'])){
		$lowerLim = $_GET['pageNum']*5;
	}else{
		$lowerLim = 0;
	}
$sql = "SELECT * FROM User LIMIT $lowerLim,5";
$result = mysqli_query($dbcon, $sql);

if (mysqli_num_rows($result) < 1) {
    echo '<div class="w3-panel w3-pale-red w3-card-2 w3-border w3-round">Nothing to display</div>';
}

	?>
<table class="center" border='1'  style='table-layout: fixed;width:90%'>
	<?php
while ($row = mysqli_fetch_assoc($result)) {
	echo "<tr>";
    $id = htmlentities($row['id']);
    $username = htmlentities($row['username']);
    $email = htmlentities($row['email']);

	$sqlRights = "SELECT * FROM userRights WHERE userID = $id";
	$resultRights = mysqli_query($dbcon, $sqlRights);
	if ($rowRights = mysqli_fetch_assoc($resultRights)) {
		$canSeeOrders = $rowRights['canSeeOrders'];
		$canDeleteOrders = $rowRights['canDeleteOrders'];
		$canCreateOrders = $rowRights['canCreateOrders'];
		$canEditOrders = $rowRights['canEditOrders'];
		$canSeeInvoices = $rowRights['canSeeInvoices'];
		$canCreateInvoices = $rowRights['canCreateInvoices'];
		$canDeleteInvoices = $rowRights['canDeleteInvoices'];
		$canEditOrders = $rowRights['canEditOrders'];
		$canEditInvoices = $rowRights['canEditInvoices'];
		$isAdmin = $rowRights['isAdmin'];

	}
    echo "<td>User:$username</td>";

	echo "<td>";
	?>
        <form method="POST">
        	<?php
        	if(!$canSeeOrders){
        		echo '<input type="checkbox" name="yesno">';
        	}else{
        		echo '<input type="checkbox" name="yesno" checked>';
        	}?>
		<input name=userID value="<?php echo $id;?>" hidden>
		<input name=rightName value="canSeeOrders" hidden>

		<button type="submit">Change</button>
		</form>
		</td>
    <?php
	echo "<td>";
		?>
        <form method="POST">
        	<?php
        	if(!$canDeleteOrders){
        		echo '<input type="checkbox" name="yesno">';
        	}else{
        		echo '<input type="checkbox" name="yesno" checked>';
        	}?>
		<input name=userID value="<?php echo $id;?>" hidden>
		<input name=rightName value="canDeleteOrders" hidden>

		<button type="submit">Change</button>
		</form>
		</td>
    <?php
	echo "<td>";
		?>
        <form method="POST">
        	<?php
        	if(!$canCreateOrders){
        		echo '<input type="checkbox" name="yesno">';
        	}else{
        		echo '<input type="checkbox" name="yesno" checked>';
        	}?>
		<input name=userID value="<?php echo $id;?>" hidden>
		<input name=rightName value="canCreateOrders" hidden>

		<button type="submit">Change</button>
		</form>
		</td>
    <?php
	echo "<td>";
	?>
        <form method="POST">
        	<?php
        	if(!$canSeeInvoices){
        		echo '<input type="checkbox" name="yesno">';
        	}else{
        		echo '<input type="checkbox" name="yesno" checked>';
        	}?>
		<input name=userID value="<?php echo $id;?>" hidden>
		<input name=rightName value="canSeeInvoices" hidden>

		<button type="submit">Change</button>
		</form>
		</td>
    <?php
	echo "<td>";
	?>
        <form method="POST">
        	<?php
        	if(!$canCreateInvoices){
        		echo '<input type="checkbox" name="yesno">';
        	}else{
        		echo '<input type="checkbox" name="yesno" checked>';
        	}?>
		<input name=userID value="<?php echo $id;?>" hidden>
		<input name=rightName value="canCreateInvoices" hidden>

		<button type="submit">Change</button>
		</form>
		</td>
    <?php
	echo "<td>";
	?>
        <form method="POST">
        	<?php
        	if(!$canDeleteInvoices){
        		echo '<input type="checkbox" name="yesno">';
        	}else{
        		echo '<input type="checkbox" name="yesno" checked>';
        	}?>
		<input name=userID value="<?php echo $id;?>" hidden>
		<input name=rightName value="canDeleteInvoices" hidden>

		<button type="submit">Change</button>
		</form>

		
    <?php
	echo "<td>";
		?>
        <form method="POST">
        	<?php
        	if(!$canEditInvoices){
        		echo '<input type="checkbox" name="yesno">';
        	}else{
        		echo '<input type="checkbox" name="yesno" checked>';
        	}?>
		<input name=userID value="<?php echo $id;?>" hidden>
		<input name=rightName value="canEditInvoices" hidden>

		<button type="submit">Change</button>
		</form>
		</td>
		
    <?php
	echo "<td>";
		?>
        <form method="POST">
        	<?php
        	if(!$canEditOrders){
        		echo '<input type="checkbox" name="yesno">';
        	}else{
        		echo '<input type="checkbox" name="yesno" checked>';
        	}?>
		<input name=userID value="<?php echo $id;?>" hidden>
		<input name=rightName value="canEditOrders" hidden>

		<button type="submit">Change</button>
		</form>
		</td>
    <?php
	echo "<td>isadmin:$isAdmin</td>";
}
	echo "</tr>"
?>
	</table>
	
<?php

	$sql = "SELECT * FROM User";
	if ($result=mysqli_query($dbcon,$sql)) {
	    $rowcount=mysqli_num_rows($result);
	    for($x=0;$x<=$rowcount/5;$x+=1){
	    	$pageNum = $x + 1;
	    	echo "<a href=users.php?pageNum=$x>" . $pageNum . "</a> | ";
	    }
	}
	
include("footer.php");
?>



