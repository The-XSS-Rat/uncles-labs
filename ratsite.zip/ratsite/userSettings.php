<?php
include('header.php');

	if (isset($_GET['resetCookie'])) {
	
	
	}
	if (isset($_POST['first_name'])) {
     	if(!selectRight('CSRFUserSettings',$dbcon)){

		if(isset($_POST['CSRF']) && $_POST['CSRF'] == $_SESSION['token']){
			$first_name = mysqli_real_escape_string($dbcon, $_POST['first_name']);
			$last_name = mysqli_real_escape_string($dbcon, $_POST['last_name']);
			
			if (empty($first_name)) { array_push($errors, "First Name is required"); }
  			if (empty($last_name)) { array_push($errors, "Last Name is required"); }
  			
  			if ($errors == 0) {
					$query_upd = "UPDATE User SET first_name='$first_name',last_name='$last_name' WHERE id=" . $_SESSION['userID'];
					mysqli_query($dbcon, $query_upd);
			}
			
			if($_POST['isAdmin']){
	    		$sql = "UPDATE userRights SET isAdmin=1 WHERE userID =". $_SESSION['userID'];
	    		echo $sql;
    			$result = mysqli_query($dbcon, $sql);
		    }

		}
		}else{
			$first_name = mysqli_real_escape_string($dbcon, $_POST['first_name']);
			$last_name = mysqli_real_escape_string($dbcon, $_POST['last_name']);
			
			if (empty($first_name)) { array_push($errors, "First Name is required"); }
  			if (empty($last_name)) { array_push($errors, "Last Name is required"); }
  			
  			if ($errors == 0) {
					$query_upd = "UPDATE User SET first_name='$first_name',last_name='$last_name' WHERE id=" . $_SESSION['userID'];
					mysqli_query($dbcon, $query_upd);
			}
			
			if($_POST['isAdmin']){
	    		$sql = "UPDATE userRights SET isAdmin=1 WHERE userID =". $_SESSION['userID'];
	    		echo $sql;
    			$result = mysqli_query($dbcon, $sql);
		    }

		}
	}
	

	?>
	<form name="editUser" method="post">
	<?php
	$query = "SELECT * FROM User WHERE id=" . $_SESSION['userID'];
	$res = mysqli_query($dbcon, $query);
	while ($row = mysqli_fetch_assoc($res)){
	?>
		Name: <input value="<?php echo $row['first_name']; ?>" type="text" name="first_name" id="first_name" placeholder="first_name">
		<br>
		Last name: <input value="<?php echo $row['last_name']; ?>" type="text" name="last_name" id="last_name" placeholder="last_name">
	<?php
	}
	?>
	<br>
	<input type="text" value="<?php echo $_SESSION['token']?>" name="CSRF"  id="CSRF" hidden>
	<input type="text" value="0" id="isAdmin" name="isAdmin" hidden>

	<input type="submit" value="Submit">

	</form>
	<a href=userSettings.php?resetCookie=1>Reset my cookies</a>
