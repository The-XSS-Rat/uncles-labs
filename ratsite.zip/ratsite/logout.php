<!DOCTYPE html>
<html lang="en"> 
<body>
 <?php include('header.php'); ?>
<?php 
session_unset();
    	echo "<script>window.location.replace('index.php') </script>";





?>


</body> 
 </html>


