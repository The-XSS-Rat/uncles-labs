<!DOCTYPE html>
<html lang="en">

<?php
include('header.php');

if (isset($_POST['username'])){	
$username = mysqli_real_escape_string($dbcon, $_POST['username']);
$password = mysqli_real_escape_string($dbcon, $_POST['password']);
}

// Form validation
if (empty($username)) { array_push($errors, "Username is required!"); echo $errors; } 
if (empty($password)) { array_push($errors, "Password is required!"); echo $errors; }

//Try to log them in

if (($username && $password)) { 
	$query = "SELECT * FROM User WHERE username= '$username' AND pass='$password' LIMIT 1";
	$result = mysqli_query($dbcon, $query);
	$user = mysqli_fetch_assoc($result);
	if (!$user){
		array_push($errors, "Username or Password is incorrect");
		echo "Username or Password is incorrect";
	} else {
		$_SESSION['login_user'] = $username;
		if(selectRight('A7CryptoFailureShowPasswordUnencrypted',$dbcon)){
			$_SESSION['greeting'] = $user['last_name'] . "," . $user['first_name'] . "<br>" . "<b>Your password is: </b>" . $user['pass'];
		}else{
			$_SESSION['greeting'] = $user['last_name'] . "," . $user['first_name'];		
		}
		$_SESSION['userID'] = $user['id'];
    	echo "<script>window.location.replace('index.php') </script>";
		echo "<b>Welcome</b>" . $_SESSION['login_user'];
	}
	
}

?>

<body>
<div class="center">
<style>
	.center{
	margin: auto;
	width: 60%;
	text-align: center;
	padding: 10px;
	}

</style>

<form action="login.php" method="post">
	<label for="username">Username:</label><br>
	<input type="text" id="username" name="username"><br>
	<label for="password">Password:</label><br>
	<input type="password" id="password" name="password"><br>
	  <img id="captcha" src="../securimage/securimage_show.php" alt="CAPTCHA Image" />
  <input type="text" name="captcha_code" size="10" maxlength="6" />
  <a href="#" onclick="document.getElementById(\'captcha\').src = \'../securimage/securimage_show.php?\' + Math.random(); return false">[ Different Image ]</a><br>
	<input type="submit" id="submit" name="submit" value="Submit">
</form>
</div>
</body>





</html>

