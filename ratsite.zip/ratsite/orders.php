<!DOCTYPE html>
<html lang="en"> 
<body>
<div class="center">

	 <?php include('header.php'); 
 
 
     	if(!selectRight('BACOrdersOverview',$dbcon)){
     		include('security.php');
     		if (!$userRights['canSeeOrders']) {
    			header("location: login.php");
    			exit();
			}
     	}
?>
<form>
Search on the orders' title:
<input name="searchTerm">
<input type="submit">
</form>

<br>

<?php


$userID = $_SESSION['userID'];

if(isset($_GET['searchTerm'])){
	$searchterm = $_GET['searchTerm'];
	if(!selectRight('tmlEntDisabledOrdersSearch',$dbcon)){
		echo "Searching for " . htmlentities($searchterm);
	}else{
		echo "Searching for " . $searchterm;
	}
	$sql = "SELECT * FROM orders where description='" . $searchterm . "'";
}else{
	if(isset($_GET['pageNum'])){
		$lowerLim = $_GET['pageNum']*5;
	}else{
		$lowerLim = 0;
	}
	$sql = "SELECT * FROM orders WHERE userID = $userID LIMIT $lowerLim,5";
}
$result = mysqli_query($dbcon, $sql); 
echo "<br>";
echo "<table border='1'  style='table-layout: fixed;width:100%'>";
echo "<tr>";
echo "<td><h5>Invoice id</h5></td>";
echo "<td><h5>Amount</h5></td>";
echo "<td><h5>Description<h5></td>";
echo "<td><h5>Edit</h5></td>";
echo "<td><h5>Delete</h5></td>";
echo "</tr>";

while ($row = mysqli_fetch_assoc($result)) { 
    echo "<tr>";
    	echo "<td>" . $row['inv_id'] . "</td>";
    	echo "<td>" . $row['qty'] . "</td>";
		if(selectRight('htmlEntDisableOrdersOverview',$dbcon)){
    		echo "<td>" . $row['description'] . "</td>";
    	}else{
    		echo "<td>" . htmlentities($row['description']) . "</td>";
    	}
    	
    	if($userRights['canEditOrders']){
			echo "<td>" . "<a href=https://hackxpert.com/ratsite/editorder.php?id=" . $row['inv_id'] . ">Edit item</a></td>";
		}
	if($userRights['canDeleteOrders']){
			echo "<td>" . "<a href=https://hackxpert.com/ratsite/delOrder.php?id=" . $row['inv_id'] . ">Delete item</a></td>";
		}https://www.youtube.com/watch?v=kWZ2LlvsVOk
    echo "</tr>";
}
echo "</table>";
?>
</div>
<div>

Go to page: <br>
<?php

	$sql = "SELECT * FROM orders WHERE userID=$userID";
	if ($result=mysqli_query($dbcon,$sql)) {
	    $rowcount=mysqli_num_rows($result);
	    for($x=0;$x<=$rowcount/5;$x+=1){
	    	$pageNum = $x + 1;
	    	echo "<a href=orders.php?pageNum=$x>" . $pageNum . "</a> | ";
	    }
	}
	
	
	
	
	if($userRights['canCreateOrders']){
        echo '<br><a href="neworder.php">Create New Order</a> |';
    }
?>

</div>

</body>
 </html>


