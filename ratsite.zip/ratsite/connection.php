<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-8L64ZBYXXW"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-8L64ZBYXXW');
</script>
<?php
session_start();


$dbhost 	= "localhost";
$dbuser 	= "toor";
$dbpass 	= "toor";
$dbname 	= "ratsite";
$charset 	= "utf8";
$dbcon = mysqli_connect($dbhost, $dbuser, $dbpass);
if (!$dbcon) {
    die("Connection failed" . mysqli_connect_error());
}
mysqli_select_db($dbcon,$dbname);
mysqli_set_charset($dbcon,$charset);
