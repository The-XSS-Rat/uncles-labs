<!DOCTYPE html>
<html lang="en">
<?php include('header.php'); ?>
<?php

if (isset($_POST['firstname'])) {
    $contactID = mysqli_real_escape_string($dbcon, $_POST['contactID']);
	$firstname = mysqli_real_escape_string($dbcon, $_POST['firstname']);
	$lastname = mysqli_real_escape_string($dbcon, $_POST['lastname']);
	if(isset($_POST['public'])){
		$public = 1;
	}else{
		$public = 0;
	}
	$email = mysqli_real_escape_string($dbcon, $_POST['email']);

	$inv_query = "UPDATE contacts set firstname=\"$firstname\", lastname=\"$lastname\", public=$public, email=\"$email\"
		WHERE id=$contactID";
				if(!selectRight('CSRFEditContact',$dbcon)){
					if(isset($_POST['CSRF']) && $_POST['CSRF'] == $_SESSION['token']){
						mysqli_query($dbcon, $inv_query);
					}
				}else{
						mysqli_query($dbcon, $inv_query);				
				}
				echo $inv_query;
	sleep(2);
    echo "<script>window.location.replace('contacts.php') </script>";

}





?>


<form method="post"  >
<?php

if (isset($_GET['id'])) {
	$contactID = mysqli_real_escape_string($dbcon, $_GET['id']);
	$invlist_query = "SELECT * FROM contacts WHERE id=" . $contactID;
	$invresults = mysqli_query($dbcon, $invlist_query);
	while ($row = mysqli_fetch_assoc($invresults)){
		if($row['userID'] != $_SESSION['userID'] && !$row['public']){
			echo "error, not your item";
			die;
		}
		?>
		contactID: <input type='text'  name='contactID' id='contactID' value='<?php echo $row['id']; ?>' readonly>
		<br>
		firstname: <input type='text'  name='firstname' id='firstname' value='<?php echo $row['firstname']; ?>'>
		<br>
		lastname: <input value="<?php echo $row['lastname']; ?>" type="text" name="lastname" id="lastname">
		<br>
		email: <input value="<?php echo $row['email']; ?>" type="text"  name="email" id="email" placeholder="Street">
		<br>
		<?php
		if($row['public']){
		?>
			public: <input type="checkbox"  name="public" id="public" checked>
		<?php
		}else{
		?>
			public: <input type="checkbox"  name="public" id="public">
		<?php
		}
		?>

		<input type="text" value="<?php echo $_SESSION['token']?>" name="CSRF"  id="CSRF" hidden>

		<br>		
		<?php
	}
}
?>
<input type="submit" value="Submit">

</form>








</html>
