<?php

	include('header.php');


	if(isset($_GET['display'])){
		if(!selectRight('tmlDisplayOnProcessCheese',$dbcon)){
			echo htmlentities($_GET['display']);
		}else{
			echo $_GET['display'];		
		}
		die();
	}
	
	//This makes XXE possible
	if(!selectRight('XXECheeseProcessor',$dbcon)){
    	libxml_disable_entity_loader (true);
	}else{
	    libxml_disable_entity_loader (false);
	}
    //Grab the input sent to the PHP file (POST body)
    $xmlfile = file_get_contents('php://input');
    //Create a new DOM document to send the XML to
    $dom = new DOMDocument();
    $dom->loadXML($xmlfile, LIBXML_NOENT | LIBXML_DTDLOAD);
    //Grab the data from the file
    $cheese = simplexml_import_dom($dom);
    $cheeseType = $cheese->cheeseType;
    if($cheeseType==""){
    	echo "Please make a POST request with the following data\<br><br>&lt;cheese><br>&nbsp;&nbsp;&nbsp;
    &lt;cheeseType>Test&lt;/cheeseType><br>
&lt;/cheese>";
    }else{
	    echo "We will process $cheeseType";
    }
    
?> 
