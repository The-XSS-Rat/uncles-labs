<!DOCTYPE html>
<html lang="en">
<body>
<div class="center">
<?php include('header.php');

if(!selectRight('BACInvoicesOverview',$dbcon)){
    include('security.php');
     if (!$userRights['canSeeInvoices']) {
    	header("location: login.php");
    	exit();
	}
}
?>

<form>
Search on the senders' name:
<input name="searchTerm">
<input type="submit">
</form>


<br>

<?php
$userID = $_SESSION['userID'];

if(isset($_GET['searchTerm'])){
	$searchterm = $_GET['searchTerm'];
	if(selectRight('tmlContacts',$dbcon)==1){
		echo "Searching for " . $searchterm;
	}elseif(selectRight('tmlContacts',$dbcon)==2){
		$searchterm = str_replace("alert","",$searchterm);
		echo "Searching for " . $searchterm;
	}elseif(selectRight('tmlContacts',$dbcon)==3){
		$searchterm = str_replace("alert","",$searchterm);
		$searchterm = str_replace("confirm","",$searchterm);
		$searchterm = str_replace("prompt","",$searchterm);
		$searchterm = str_replace("script","",$searchterm);
		echo "Searching for " . $searchterm;
	}elseif(selectRight('tmlContacts',$dbcon)==4){
		$searchterm = str_replace("alert","",$searchterm);
		$searchterm = str_replace("confirm","",$searchterm);
		$searchterm = str_replace("prompt","",$searchterm);
		$searchterm = str_replace("script","",$searchterm);
		$searchterm = str_replace("<","",$searchterm);
		echo "Searching for " . urldecode($searchterm);
	}else{
		echo "Searching for " . htmlentities($searchterm);
	}
	$sql = "SELECT * FROM contacts where firstname='" . $searchterm . "'";
}else{
	if(isset($_GET['pageNum'])){
		$lowerLim = $_GET['pageNum']*5;
	}else{
		$lowerLim = 0;
	}
	
	$sql = "SELECT * FROM contacts WHERE userID = $userID OR public=1 LIMIT $lowerLim,5";
	
}
$result = mysqli_query($dbcon, $sql); 
echo "<br>";
echo "<table border='1'  style='table-layout: fixed;width:100%'>";
echo "<tr>";
echo "<td><h5>ID</h5></td>";
echo "<td><h5>First name</h5></td>";
echo "<td><h5>lastname</h5></td>";
echo "<td><h5>email</h5></td>";
echo "<td><h5>public</h5></td>";
echo "<td><h5></h5></td>";
echo "<td><h5></h5></td>";

echo "</tr>";

while ($row = mysqli_fetch_assoc($result)){
    echo "<tr>";
	if(selectRight('tmlContacts',$dbcon)){
   	 	echo "<td>" . $row['id'] . "</td>";
   	 	echo "<td>" . $row['firstname'] . "</td>";
		echo "<td>" . $row['lastname'] . "</td>";
    	echo "<td>" . $row['email'] . "</td>";
   	 	echo "<td>" . $row['public'] . "</td>";
    }else{
    	echo "<td>" . htmlentities($row['id']) . "</td>";
   	 	echo "<td>" . htmlentities($row['firstname']) . "</td>";
		echo "<td>" . htmlentities($row['lastname']) . "</td>";
    	echo "<td>" . htmlentities($row['email']) . "</td>";
   	 	echo "<td>" . htmlentities($row['public']) . "</td>";
    }
	if($row['userID'] == $_SESSION['userID']){
			echo "<td>" . "<a href=editContact.php?id=" . $row['id'] . ">Edit
			item</a></td>";
			echo "<td>" . "<a href=delContact.php?id=" . $row['id'] . ">Delete item</a></td>"; }

	}
    echo "</tr>";



echo "</table>";

?>

</div>
<div class="center" >

Go to page: <br>
<?php

	$sql = "SELECT * FROM contacts WHERE userID = $userID";
	if ($result=mysqli_query($dbcon,$sql)) {
	    $rowcount=mysqli_num_rows($result);
	    for($x=0;$x<=$rowcount/5;$x+=1){
	    	$pageNum = $x + 1;
	    	echo "<a href=contacts.php?pageNum=$x>" . $pageNum . "</a> | ";
	    }
	}
        echo '<a href="newContact.php">Create New Contact</a> |';
?>




</div>


</body>



</html>
