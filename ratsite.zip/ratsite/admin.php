<?php
include('config.php');
include('header.php');

if($_SESSION['password'] != 'WesleyIsACheeseBoy!'){
?>
<form>
pass: <input type='text'  name='password' id='password'>
<input type="submit" value="Submit">
</form>

<?php
if(isset($_GET['password'])){	
	$_SESSION['password'] = $_GET['password'];

	echo "<script>window.location.replace('admin.php');</script>";
}
}else{
$sql = "SELECT * FROM exploits";
$result = mysqli_query($dbcon, $sql); 


echo "<table border='1' style='margin-left: auto;margin-right: auto;'>";
echo "<tr><td>id</td><td>name</td><td>description</td><td>value</td><td>URL</td>";

while ($row = mysqli_fetch_assoc($result)) { 
	echo "<tr>";
	echo "<td>" . $row['id'] . "</td>";
	echo "<td>" . $row['name'] . "</td>";
	echo "<td>" . $row['description'] . "</td>";
	echo "<td>" . $row['value'] . "</td>";
	echo "<td>" . $row['url'] . "</td>";
	echo "<td><a href=admin.php?edit=" . $row['id'] . ">Edit</a></td>";
	echo "<td><a href=admin.php?del=" . $row['id'] . ">Delete</a></td>";
	echo "<tr>";	
}

if(isset($_GET['edit'])){
$id = mysqli_real_escape_string($dbcon, $_GET['edit']);
$sqlGetExploit = "SELECT * FROM exploits WHERE id=$id";
$result = mysqli_query($dbcon, $sqlGetExploit);

while ($row = mysqli_fetch_assoc($result)) { 
	$name = $row['name'];
	$description = $row['description'];
	$value = $row['value'];
	$url = $row['url'];
} 
}
?>

<tr>
<form>
<td><input type='text'  name='id' id='id' value='<?php echo $id;?>' readonly></td>
<td>name: <input type='text'  name='name' id='name' value='<?php echo $name;?>'></td>
<td>description: <input type='text'  name='description' id='description' value='<?php echo $description;?>'></td>
<td>value: <input type='number'  name='value' id='value' value='<?php echo $value;?>'></td>
<td>url: <input type='text'  name='url' id='url' value='<?php echo $url;?>'></td>
<td><input type="submit" value="Submit"></td>
</form>
</tr>
</table>

<a href=admin.php?allToZero=1>set All to 0</a>
! <a href=admin.php?allToOne=1>set All to 1</a>
! <a href=admin.php?rand=1>Set all to random values</a>
<?php

if(isset($_GET['rand'])){
	$sqlUpd="UPDATE exploits SET value=ROUND(RAND())";
	mysqli_query($dbcon, $sqlUpd);
	echo "<script>window.location.replace('admin.php');</script>";
}

if(isset($_GET['del'])){
	$id = mysqli_real_escape_string($dbcon, $_GET['del']);
	$sqlInsert="DELETE FROM exploits  WHERE id=$id";
	mysqli_query($dbcon, $sqlInsert);
	echo "<script>window.location.replace('admin.php');</script>";
	die();
}

if(isset($_GET['allToZero'])){
	$sqlUpd="UPDATE exploits SET value=0";
	mysqli_query($dbcon, $sqlUpd);
	echo "<script>window.location.replace('admin.php');</script>";
}

if(isset($_GET['allToOne'])){
	$sqlUpd="UPDATE exploits SET value=1";
	mysqli_query($dbcon, $sqlUpd);
	echo "<script>window.location.replace('admin.php');</script>";
}

if(isset($_GET['name'])){
	$name = mysqli_real_escape_string($dbcon, $_GET['name']);
	$description = mysqli_real_escape_string($dbcon, $_GET['description']);
	$value = mysqli_real_escape_string($dbcon, $_GET['value']);
	$url = mysqli_real_escape_string($dbcon, $_GET['url']);
	$id = mysqli_real_escape_string($dbcon, $_GET['id']);
	if($_GET['id'] != ''){
		$sqlInsert="UPDATE exploits SET name = '$name', description='$description',value=$value,url='$url' WHERE id=$id";
	}else{
		$sqlInsert="INSERT INTO exploits VALUES (NULL,'$name','$description',$value,'$url')";
	}
	mysqli_query($dbcon, $sqlInsert);
	echo $sqlInsert;

	echo "<script>window.location.replace('admin.php');</script>";

}
}
?>
