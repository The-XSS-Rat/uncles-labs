<!DOCTYPE html>
<html lang="en">
<?php include('header.php'); ?>

<div class="wrapper">
  <div>
    Uncle Rat
	<hr>
  Dave Kupratis - Developer, project management<br><img src="images/blob.jpeg"">
  <br>
  "Sometimes you have to take multiple steps backwards to go forward in life."
  <br>
  <a href=https://twitter.com/dkupras>https://twitter.com/dkupras</a><br>
  <a href=https://www.linkedin.com/in/davidkupratis>https://www.linkedin.com/in/davidkupratis</a><br>
  <a href=https://www.instagram.com/david_kupratis/>https://www.instagram.com/david_kupratis/</a><br>
  <a href=https://www.facebook.com/dkupras/>https://www.facebook.com/dkupras/</a><br>
  <a href=https://github.com/DavidKupratis>https://github.com/DavidKupratis</a>
  <hr>
  </div>
</div>

