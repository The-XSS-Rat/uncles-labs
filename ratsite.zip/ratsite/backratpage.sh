#!/bin/bash

sudo cp  /var/www/html/ratsite/*.* /mnt/Extra/Backups/ratsite





