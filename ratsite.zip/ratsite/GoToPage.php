<?php
include('header.php');

if(isset($_GET['url'])){
	if(!selectRight('OpenRedirect',$dbcon)){
		if(strstr($_GET['url'],$_SERVER['HTTP_HOST'])){
	    	$redirect_url = $_GET['url'];
    		echo "<script>window.location.replace('" . $redirect_url . "') </script>";
		}else{
			echo "You can only direct to " . $_SERVER["HTTP_HOST"];
		}	
	}else{
    	$redirect_url = $_GET['url'];
    	echo "<script>window.location.replace('" . $redirect_url . "') </script>";
	}

}

?>


<form method="GET">
    URL:<input type="text" id="url" name="url"><br>
    <input type="submit">	
</form>
