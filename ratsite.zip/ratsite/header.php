<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-8L64ZBYXXW"></script>
<script src="secret.js"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-8L64ZBYXXW');
</script>

<head>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5043827651856884"
            crossorigin="anonymous"></script>
<title>Welcome to RatSite!</title>
<script src="assets/ratsite.js"></script>

<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js"></script>
<?php include('connection.php'); 
include('JWT.php'); 
if (!isset($_SESSION['token'])) {
        $_SESSION['token'] = bin2hex(random_bytes (32));
	
	}

if(file_exists('config.ini')){
	$ini = parse_ini_file('config.ini');
}


function selectRight($name,$dbcon) {
	$sql = "select value from exploits where name='$name'";
	$result = mysqli_query($dbcon, $sql);
	$sqlExploits = mysqli_fetch_assoc($result);
	return $sqlExploits['value'];
}

?>
 <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 <style>

        .center {
        margin: auto;
        width: 60%;
        padding: 10px;
	text-align: center;
       }
  	. {
    width: 220px;
    height: 50px;
    border: none;
    outline: none;
    color: #111111;
    background: #FFFFFF;
    cursor: pointer;
    position: relative;
    z-index: 0;
    border-radius: none;
}
.button {
	  border-radius: 4px;
  	  border: 2px solid black;
}
/*.:before {
    content: '';
    background: linear-gradient(45deg, #ff0000, #ff7300, #fffb00, #48ff00, #00ffd5, #002bff, #7a00ff, #ff00c8, #ff0000);
    position: absolute;
    top: -2px;
    left: -2px;
    background-size: 500%;
    z-index: -1;
    filter: blur(5px);
    width: calc(100% + 6px);
    height: calc(100% + 6px);
    animation: glowing 20s linear infinite;
    opacity: 0;
    transition: opacity .3s ease-in-out;
    border-radius: 20px;
}
*/
div {
grid-column: 2;

}

.:active {
    color: #000
}

.:active:after {
    background: transparent;
}

.:hover:before {
    opacity: 1;
}

.:after {
    z-index: -1;
    content: '';
    position: absolute;
    width: 100%;
    height: 100%;
    background: #111;
    left: 0;
    top: 0;
    border-radius: 10px;
}

@keyframes glowing {
    0% { background-position: 0 0; }
    50% { background-position: 400% 0; }
    100% { background-position: 0 0; }
}
.wrapper {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
  grid-auto-rows: minmax(100px, auto);
}
.one {
  grid-row: 1;
}
.two {
  grid-row: 2;
}
.three {
  grid-row: 3;
}
.four {
  grid-row: 4;
}
.five {
  grid-row: 5;
}
.six {
  grid-row: 6;
}
<?php include('bg.css'); ?>
 </style>
  
</head>


	
<div class="center">
<img src="ratpic.jpg" onmouseover="<style>filter: invert(100%);</syle>" style="border: 8px solid #000;" height="128" width="300" >
<h1> Rat Pack Shop </h1>
<nav>
        <?php 
        if (isset($_SESSION['login_user'])){
            ?><a href="index.php" class="button" >Home</a> | <a href="contacts.php" class="button" >Contacts</a> |
			<?php
        	$sql = "select * from userRights where userID=" . $_SESSION['userID'];
        	$result = mysqli_query($dbcon, $sql);
			$userRights = mysqli_fetch_assoc($result);

        	if($userRights['canSeeInvoices']){
        		echo '<a href="invoices.php" class="button">Invoices</a> |';
        	}
        	if($userRights['canSeeOrders']){
        		echo '<a href="orders.php" class="button" >Orders</a> |';
        	}

        	echo '<a href="GoToPage.php" class="button">Page Opener</a> | <a href="processCheese.php" class="button">Cheese Processor</a> | <a href="userSettings.php" class="button">User settings</a>';
            if($userRights['isAdmin']){
        		echo ' | <a href="users.php" class="button">Users</a> ';
        	}
        	echo "<br>";
        	echo '| <a href="JWT-check.php" class="button">Checker</a> ';
        	echo '| <a href="angular_test.php" class="button">Contact customer support</a> ';

        	echo '| <a href="logout.php" class="button">Logout</a>';
        }else{
        	echo '<a href="register.php" class="button">Register</a> | <a href="login.php" class="button">Login</a>';
        }
        ?>
</nav>
</div>

