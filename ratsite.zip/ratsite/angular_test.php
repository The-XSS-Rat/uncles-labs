<?php
include('header.php');
include('security.php');

if(selectRight('CSTICustomerSupport',$dbcon)){
	echo "<script src=\"https://ajax.googleapis.com/ajax/libs/angularjs/1.4.6/angular.js\"></script>";
}

?>

<h3>Contact customer support</h3>
<form>
Message: <input type='text'  name='q' id='q'>
<button type="submit">Register</button>
</form>

<?php

if(isset($_GET['q'])){
	echo "Your Query: <div ng-app>" . htmlentities($_GET['q']) . "</div> has been sent over to customer support.";
}
?>