<!DOCTYPE html>
<html lang="en">
<?php include('header.php'); ?>
<?php

if(!$ini['BACInvoicesDetail']){
    include('security.php');
}

if (isset($_POST['invDATE'])) {
	//$invID = mysqli_real_escape_string($dbcon, $_POST['invID']);
	$invDATE = mysqli_real_escape_string($dbcon, $_POST['invDATE']);
	$fromNAME = mysqli_real_escape_string($dbcon, $_POST['fromNAME']);
	$fromST = mysqli_real_escape_string($dbcon, $_POST['fromST']);
	$fromSTATE = mysqli_real_escape_string($dbcon, $_POST['fromSTATE']);
	$total = mysqli_real_escape_string($dbcon, $_POST['total']);


//Check to make sure form is complete when posting:
//if (empty($invID)) {  array_push($errors, "Invoice ID must be set"); echo "Invoice ID must be set! "; } else { $_SESSION['invID']= $invID;  }
if (empty($invDATE)) { array_push($errors, "Invoice Date must be set"); echo "Invoice Date must be set! "; } else { $_SESSION['invDATE']= $invDATE; }
if (empty($fromNAME)) { array_push($errors, "Invoice Name must be set"); echo "Invoice Name must be set! "; } else { $_SESSION['fromNAME']= $fromNAME; }
if (empty($fromST)) { array_push($errors, "Invoice Street must be set"); echo "Invoice Street must be set! "; } else {$_SESSION['fromST']= $fromST; }
if (empty($fromSTATE)) { array_push($errors, "Invoice State must be set"); echo "Invoice State must be set! "; } else {$_SESSION['fromSTATE']= $fromSTATE; }
if (empty($total)) { array_push($errors, "Invoice Total must be set"); echo "Invoice Total must be set! "; } else {$_SESSION['total']= $total; }


//Check to make sure no duplicate ID is entered:
//$id_check_query = "SELECT * FROM invoice WHERE inv_id='$invID' LIMIT 1";
//$result = mysqli_query($dbcon, $id_check_query);
//$idchk = mysqli_fetch_assoc($result);
//if ($idchk) {
//	if ($idchk['inv_id'] === $invID) {
//	array_push($errors, "ID already exists ");
//		die("ID already exists ");
		
//	}
	
//}
if ($errors == 0) {
	$userID = $_SESSION['userID'];
	$inv_query = "INSERT INTO invoice(date, from_name, from_street, from_state, total,userID)
		VALUES('$invDATE', '$fromNAME', '$fromST', '$fromSTATE', '$total','$userID')";
	mysqli_query($dbcon, $inv_query);
	echo "<h1>Submitted Successfully!</h1>";
	sleep(2);
	$_SESSION['invDATE']= "";
	$_SESSION['fromNAME']="";
	$_SESSION['fromST']="";
	$_SESSION['fromSTATE']="";
	$_SESSION['total']="";
	header("location:/ratsite/invoices.php");
	}

}

?>


<form name="newinv" action="/ratsite/newinv.php" method="post"  >


<div></div>
</div>
</div>
<div>
<label>Date:  </label>
<div>
<div></div>
<input value="<?php echo $_SESSION['invDATE']; ?>" type="date"  name="invDATE" id="invDATE" placeholder="Date" required>
</div>
</div>
<div>
<label>Name:  </label>
<div>
<div></div>
<input value="<?php echo $_SESSION['fromNAME']; ?>" type="text" name="fromNAME" id="fromNAME" placeholder="Name" required>
</div>
</div>
<div>
<label>Street:  </label>
<div>
<div></div>
<input value="<?php echo $_SESSION['fromST']; ?>" type="text"  name="fromST" id="fromST" placeholder="Street" required>
</div>
</div>
<div>
<label>State:  </label>
<div>
<div></div>
<input value="<?php echo $_SESSION['fromSTATE']; ?>" type="text"  name="fromSTATE" id="fromSTATE" placeholder="State" required>
</div>
</div>
<div>
<label>Total: </label>
<div>
<input value="<?php echo $_SESSION['total']; ?>" type="number" name="total" id="total" placeholder="Total Amount"  required>
</div>
</div>
<input type="submit" value="Submit">

</form>








</html>
